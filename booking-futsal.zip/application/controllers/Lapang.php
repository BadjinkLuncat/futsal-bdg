<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lapang extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index($id)
    {
        $this->load->model('lapang_model');
        $lapang=$this->lapang_model->find($id);
        $this->load->model('detail_lapang_model');
        $detail_lapang=$this->detail_lapang_model->get($id);
        $this->load->model('reservasi_model');
        $booking=$this->reservasi_model->get(4);
        $data['lapang']=$lapang;
        $data['peta']=explode(',', $lapang->location);
        $data['detail_lapang']=$detail_lapang;
        $jadwal=[];
        foreach ($detail_lapang as $key => $value) {
            $open=intval(date('G',strtotime($lapang->buka)));
            $close=intval(date('G',strtotime($lapang->tutup)));
            $i=1;
            for ($open; $open < $close; $open++) {
                $hour=date('G:i',mktime($open,0,0,0,0,0)); 
                $jadwal[$key][$open]['detail_id']=$value->id;
                $jadwal[$key][$open]['number']=$i++;
                $jadwal[$key][$open]['jam']=$hour;
                $jadwal[$key][$open]['status']='Kosong';
                foreach ($booking as $k => $val) {
                    if (date_format($value->tanggal_reservasi,'G:i')== $hour){
                        $jadwal[$key][$open]['status']='Isi';
                        $jadwal[$key][$open]['jam']=date_format($value->tanggal_reservasi,'G:i');
                    }
                }
                
            }
        }
        $data['jadwal']=$jadwal;
        $this->load->view('frontend/lapang',$data);
    }
    

}
