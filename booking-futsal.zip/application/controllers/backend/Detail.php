<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detail extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->library('ion_auth');
        if($this->ion_auth->logged_in()===FALSE)
        {
            redirect('admin/auth/login');
        }
    }
    
    public function index($id)
    {
        $data=array();
        $this->load->model('detail_lapang_model');
        $data['data']=$this->detail_lapang_model->lapang($id);
        $this->load->view('backend/lapang/detail/index',$data);
    }

    public function create($id){
        $data=[
            'form_name'=>'form1', 
            'form_id'=>'form1', 
            'form_action'=>base_url('admin/lapang/detail/insert'),
            'form_method'=>'post',
            'form_multipart'=>true
            ];
        $data['nama']=null;
        $data['harga']=null;
        $data['deskripsi']=null;
        $data['id_lapang']=$id;
        $this->load->view('backend/lapang/detail/form',$data);
    }

    public function edit($id){
        $data=[
            'form_name'=>'form1', 
            'form_id'=>'form1', 
            'form_action'=>base_url('admin/lapang/detail/update').'/'.$id,
            'form_method'=>'post',
            'form_multipart'=>true
            ];
        $data['nama']=null;
        $data['harga']=null;
        $data['deskripsi']=null;
        $data['id_lapang']=null;
        if ($id){
            $this->load->model('detail_lapang_model');
            $lapang=$this->detail_lapang_model->find($id);
            $data['nama']=$lapang->nama;
            $data['harga']=$lapang->harga;
            $data['deskripsi']=$lapang->deskripsi;
            $data['id_lapang']=$lapang->id_lapang;
        }
        $this->load->view('backend/lapang/detail/form',$data);
    }

    public function insert(){
        $data=$this->input->post();
        $file_name=rand(100,1000).'_'.date('YmdGis');
        $config['upload_path']   = 'assets/uploads/'; 
        $config['allowed_types'] = 'gif|jpg|png'; 
        $config['max_size']      = 1024; 
        $config['max_width']     = 1024; 
        $config['max_height']    = 768;  
        $config['file_name']    = $file_name;  
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if ( ! $this->upload->do_upload('image')) {
            $data['gambar']= 'noimage.gif'; 
            $error = array('error' => $this->upload->display_errors(),'request'=>$this->input->post());
            // var_dump($error);
        }
        else { 
            $image=$this->upload->data();
            $data['gambar']= $image['file_name'];
            // var_dump($data);
        } 
        $this->load->model('detail_lapang_model');
        $res=$this->detail_lapang_model->insert($data);
        redirect(base_url('admin/lapang/detail').'/'.$this->input->post('id_lapang'),'refresh');
    }

    public function update($id){
        $this->load->model('detail_lapang_model');
        $data=$this->input->post();
        $file_name=rand(100,1000).'_'.date('YmdGis');
        $config['upload_path']   = 'assets/uploads/'; 
        $config['allowed_types'] = 'gif|jpg|png'; 
        $config['max_size']      = 1024; 
        $config['max_width']     = 1024; 
        $config['max_height']    = 768;  
        $config['file_name']    = $file_name;  
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if ( ! $this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors(),'request'=>$this->input->post());
            // var_dump($error);
        }
        else { 
            $image=$this->upload->data();
            $data['gambar']= $image['file_name'];
            // var_dump($data);
        }
        $res=$this->detail_lapang_model->update($data,$id);
        redirect(base_url('admin/lapang/detail').'/'.$id,'refresh');
    }

    function delete($id){
        $this->load->model('detail_lapang_model');
        $res=$this->detail_lapang_model->delete($id);
        redirect(base_url('admin/lapang/detail').'/'.$id,'refresh');
    }
}
