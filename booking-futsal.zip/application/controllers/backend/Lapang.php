<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lapang extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->library('ion_auth');
        if($this->ion_auth->logged_in()===FALSE)
        {
            redirect('user/login');
        }
    }
    
    public function index()
    {
        $data=array();
        $this->load->model('lapang_model');
        $data['data']=$this->lapang_model->get();
        $this->load->view('backend/lapang/index',$data);
    }

    public function create(){
        $data=[
            'form_name'=>'form1', 
            'form_id'=>'form1', 
            'form_action'=>base_url('admin/lapang/insert'),
            'form_method'=>'post',
            'form_multipart'=>true
            ];
        $data['nama']=null;
        $data['address']=null;
        $this->load->view('backend/lapang/form',$data);
    }

    public function edit($id){
        $data=[
            'form_name'=>'form1', 
            'form_id'=>'form1', 
            'form_action'=>base_url('admin/lapang/update').'/'.$id,
            'form_method'=>'post',
            'form_multipart'=>true
            ];
        if ($id){
            $this->load->model('lapang_model');
            $lapang=$this->lapang_model->find(1);
            $data['nama']=$lapang->nama;
            $data['alamat']=$lapang->alamat;
        }
        $this->load->view('backend/lapang/form',$data);
    }

    function createEdit($id=null){
        $form=[
            'form_name'=>'form1', 
            'form_id'=>'form1', 
            'form_action'=>base_url('admin/lapang/insert'),
            'form_method'=>'post',
            'form_multipart'=>true
            ];
        $data['name']='asd';
        $data['address']='';
        if ($id){
            $this->load->model('lapang_model');
            $data['data']=$this->lapang_model->find(1);
        }
        $this->load->view('backend/lapang/form',$form);
    }

    public function insert(){
        $data=$this->input->post();
        $config['upload_path']          = '.assets/uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 100;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;
        $config['file_name']           = date('YmdGis');

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imageupload'))
        {
            $error = array('error' => $this->upload->display_errors());
            var_dump($error);
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            var_dump($data);
            $data['gambar']=$config['file_name'];
        }
        $res=$this->lapang_model->insert($data);
    }

    public function update($id){
        $this->load->model('lapang_model');
        $data=$this->input->post();
        $data=$this->input->post();
        $config['upload_path']          = '.assets/uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 100;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;
        $config['file_name']           = date('YmdGis');

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('imageupload'))
        {
            $error = array('error' => $this->upload->display_errors());
            var_dump($error);
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            var_dump($data);
            $data['gambar']=$config['file_name'];
        }
        $this->lapang_model->update($data,$id);
        redirect(base_url(),'refresh');
    }

    function delete($id){
        $this->load->model('lapang_model');
        $res=$this->lapang_model->delete($id);
        redirect(base_url(),'refresh');
    }
}
